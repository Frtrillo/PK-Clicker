<?php
                          //SQL plataforma1
                          if($recomendacion->plataforma1!=null){
                            if($recomendacion->plataforma1=='gog'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a  href="<?php echo $recomendacion->linkplataforma1;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblegog.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma1=='google'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma1;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblegoogle.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma1=='appstore'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma1;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponibleappstore.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma1=='microsoft'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma1;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblepc.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma1=='steam'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma1;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblesteam.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma1=='pc'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma1;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblepc.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma1=='imdb'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma1;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/imdb.png" ></a>
                              </div>
                              <?php
                            }
                          }
                          //SQL plataforma2
                          if($recomendacion->plataforma2!=null){
                            if($recomendacion->plataforma2=='gog'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a  href="<?php echo $recomendacion->linkplataforma2;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblegog.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma2=='google'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma2;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblegoogle.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma2=='appstore'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma2;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponibleappstore.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma2=='microsoft'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma2;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblepc.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma2=='steam'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma2;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblesteam.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma2=='pc'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma2;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblepc.png" ></a>
                              </div>
                              <?php
                            }
                          }
                          //SQL plataforma3
                          if($recomendacion->plataforma3!=null){
                            if($recomendacion->plataforma3=='gog'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a  href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblegog.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma3=='google'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblegoogle.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma3=='appstore'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponibleappstore.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma3=='microsoft'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblepc.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma3=='steam'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblesteam.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma3=='pc'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblepc.png" ></a>
                              </div>
                              <?php
                            }
                          }
                          //SQL plataforma4
                          if($recomendacion->plataforma4!=null){
                            if($recomendacion->plataforma4=='gog'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a  href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblegog.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma4=='google'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblegoogle.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma4=='appstore'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponibleappstore.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma4=='microsoft'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblepc.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma4=='steam'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma3;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblesteam.png" ></a>
                              </div>
                              <?php
                            }
                            if($recomendacion->plataforma4=='pc'){
                              ?>
                              <div class="col-lg-12 m-3">
                              <a href="<?php echo $recomendacion->linkplataforma4;?>"><img alt="Foto boton tienda" src="/fanbase/assets/img/recomendaciones/disponiblepc.png" ></a>
                              </div>
                              <?php
                            }
                          }
                          ?>