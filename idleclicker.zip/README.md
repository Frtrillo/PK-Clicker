# PK-Clicker
HTML Canvas game test.
Made for learning anbd academic  purposes. Assets copyright nintendo.
