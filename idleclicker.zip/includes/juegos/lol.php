<html lang="es">
<h1 class="text-center text-primary d-none d-sm-block">Top campeones</h1>
<div class="row no-gutters shadow p-3 mb-5 bg-dark">
    <img src="assets/img/juegos/lol/riven.png" alt="Riven" class="col-lg-4 col-md-6">
    <img src="assets/img/juegos/lol/katarina.png" alt="Katarina" class="col-lg-4 col-md-6">
    <img src="assets/img/juegos/lol/missfortune.png" alt="Miss Fortune" class="col-lg-4 col-md-6">
    <img src="assets/img/juegos/lol/akali.png" alt="Akali" class="col-lg-4 col-md-6">
    <img src="assets/img/juegos/lol/draven.png" alt="Draven" class="col-lg-4 col-md-6">
    <img src="assets/img/juegos/lol/jinx.png" alt="Jinx" class="col-lg-4 col-md-6">
    <img src="assets/img/juegos/lol/garen.png" alt="Garen" class="col-lg-4 col-md-6">
    <img src="assets/img/juegos/lol/tryndamere.png" alt="Tryndamere" class="col-lg-4 col-md-6">
    <img src="assets/img/juegos/lol/yasuo.png" alt="Yasuo" class="col-lg-4 col-md-6">
</div>