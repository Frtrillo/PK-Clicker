 <style>
    canvas{
        border:1px solid #d3d3d3;margin: 0 auto;margin-top: 115px;display: block;
    }
  </style>