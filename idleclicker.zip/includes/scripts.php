<!-- JavaScript Libraries -->
<script src="/fanbase/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/fanbase/lib/wow/wow.min.js"></script>
<script src="/fanbase/lib/owlcarousel/owl.carousel.min.js"></script>

<!-- Template Main Javascript File -->
<script src="/fanbase/assets/js/main.js"></script>

<link rel="stylesheet" type="text/css" href="//wpcc.io/lib/1.0.2/cookieconsent.min.css"/><script src="//wpcc.io/lib/1.0.2/cookieconsent.min.js"></script><script>window.addEventListener("load", function(){window.wpcc.init({"border":"thin","corners":"small","colors":{"popup":{"background":"#0d1223","text":"#2ab09c","border":"#f9f9f9"},"button":{"background":"#2ab09c","text":"#000000"}},"content":{"href":"http://fanbase.nuxsite.com/terminoslegales.php","message":"Si CONTINUAS NAVEGANDO aceptas los Términos y Condiciones.","link":"http://fanbase.nuxsite.com/terminoslegales","button":"Aceptar"},"position":"bottom"})});</script>

